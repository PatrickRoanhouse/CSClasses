#include <iostream>
using namespace std;

int main() // using 'void main()' breaks g++
{
	cout << "Hello world\n";

return 0;
}
